﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class frm1 : Form
    {

        private string ruta = "";

        public frm1()
        {
            InitializeComponent();
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                ruta = openFileDialog1.FileName;
        }

        private void btnReproducir_Click(object sender, EventArgs e)
        {
            wmp1.URL = ruta;
            wmp1.Ctlcontrols.play();
        }

        private void btnParar_Click(object sender, EventArgs e)
        {
            wmp1.Ctlcontrols.stop();
        }

        private void btnPausar_Click(object sender, EventArgs e)
        {
            wmp1.Ctlcontrols.pause();
        }
    }
}
